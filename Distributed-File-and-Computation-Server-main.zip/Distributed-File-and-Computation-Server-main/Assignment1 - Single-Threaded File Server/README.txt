CSE 5306

Asfiya Misba (1002028239)
Divya Darshi (1002090905)


File Structure:
Assignment 1
	->ServerFiles
		->download.txt //File to be downloaded
		->fileToDelete.txt //File to be deleted
		->Test.txt //File to be renamed
	->ClientFiles
		->upload.txt //File to be uploaded to the server



Steps to run the program:
- The absolute paths of the files are to be modified in the server and client program have to changed according to the directory in which this project is saved. gedit Server.java, gedit Client.java can be used to modify the files.
- To compile use javac Server.java, javac Client.java.
- To run, use java Server, java Client on two separte terminals.
