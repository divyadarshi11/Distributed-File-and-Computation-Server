Assignment 2


CSE 5306

Asfiya Misba (1002028239)
Divya Darshi (1002090905)


File Strcuture:

- Assignment2
	->Server02.java
	->ServerThread.java
	->Client.java
	->ServerFiles
		-> download.txt
		-> fileToDelete.txt
		-> Test.txt
	->ClientFiles
		-> upload.txt
		
		
We are using the following files, the path has to be changed in Client.java, Server02.java as absolute paths are used and it might be different on the test machine.
Comments are provided to change the path
