Assignment 4 (CSE 5306 - Fall 2022)
Submitted by:
	- Asfiya Misba (1002028239)
	- Divya Darshi (1002090905)
- The program runs similar to assignment3, the client waits until it receives the result in this case. To check other operations, the code has to be re-run
