Assignment 3 (CSE 5306 - Fall 2022)
Submitted by:
	- Asfiya Misba (1002028239)
	- Divya Darshi (1002090905)

Steps to run:
1. Copy the folder "Assignment3".
2. On the terminal, go to the "Assignment3" directory.
3. To view the server code use 
	- gedit Server.java 
4. To view the client code use 
	- gedit Client.java
5. Compile both the files using 
	- javac Server.java
	- javac Client.java
6. First run the server code using
	- java Server
7. Open another therminal to run the client program
	- java Client
8. Select one of the given 5 options to calculate pi, add two numbers, sort an array, multiply two matrices and to exit.
9. To add two numbers, enter the two numebrs
10. To sort an array, first enter the size of the array and then the array elements
11. To multiply two matrices, enter the dimensions of the two matrices and the values
12. Screenshots of the outputs are provided in the report
				

